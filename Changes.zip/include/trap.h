#ifndef __TRAP_H__
#define __TRAP_H__

#include "entity.h"

Entity* trap_new();

#endif // !__trap_H__