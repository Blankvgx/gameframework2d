#ifndef __BALL_H__
#define __BALL_H__

#include "entity.h"

Entity *ball_new();

#endif // !__BALL_H__